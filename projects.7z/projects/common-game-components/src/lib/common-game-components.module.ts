import { NgModule } from '@angular/core';
import { CommonGameComponentsComponent } from './common-game-components.component';

@NgModule({
  declarations: [CommonGameComponentsComponent],
  imports: [
  ],
  exports: [CommonGameComponentsComponent]
})
export class CommonGameComponentsModule { }
